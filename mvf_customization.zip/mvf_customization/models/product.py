# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import UserError


class Product(models.Model):
    _inherit = "product.product"

    product_group_id = fields.Many2one(comodel_name="mvf.product.group", string="Group")
    product_type_id = fields.Many2one(comodel_name="mvf.product.type", string="Type")
    product_item_id = fields.Many2one(comodel_name="mvf.product.item", string="Item")
    product_model_id = fields.Many2one(comodel_name="mvf.product.model", string="Model", domain="[('item_id', '=', product_item_id or False)]")
    product_document_ids = fields.One2many(comodel_name='product.document', inverse_name='product_id', string="Documents")

    def _sequence_fields(self):
        return {
            'group': 'product_group_id',
            'type': 'product_type_id',
            'item': 'product_item_id',
            'model': 'product_model_id'
        }

    def _get_default_code_sequence_format(self):
        return "%(group)s%(type)s-%(item)s%(model)s"

    def _get_sequence_increment(self, prefix):
        ''':return: A unique suffix for the code.'''
        self._cr.execute('''
                SELECT CAST(SUBSTRING(default_code FROM '-\d+$') AS INTEGER) AS suffix
                FROM product_product WHERE default_code LIKE %s ORDER BY suffix
            ''', [prefix + '-%'])
        query_res = self._cr.fetchone()
        if query_res:
            # Increment the last reference by one
            n = (-query_res[0] + 1)
            suffix = '%s' % (n < 10 and ('0%s' % n) or n)
        else:
            # Start a new indexing from 1
            suffix = '01'
        return suffix

    def _get_default_code_sequence(self):
        formatted_sequence = self._get_default_code_sequence_format()
        args = dict()
        for name, field in self._sequence_fields().items():
            args[name] = hasattr(self[field], 'code') and getattr(self[field], 'code') or ''
        code = formatted_sequence % args
        increment = self._get_sequence_increment(code)
        return '%s-%s' % (code, increment)

    def _is_need_update_sequence(self, vals):
        return len(list(set(
                self._sequence_fields().values()
            ).intersection(set(vals.keys())))) >= 1

    @api.model
    def create(self, vals):
        product_id = super(Product, self).create(vals)
        if self._is_need_update_sequence(vals):
            product_id.default_code = product_id._get_default_code_sequence()
        return product_id

    def write(self, vals):
        res = super(Product, self).write(vals)
        if self._is_need_update_sequence(vals):
            for product in self:
                product.default_code = product._get_default_code_sequence()
        return res

    def unlink(self):
        if not self.user_has_groups('mvf_customization.group_general_manager'):
            raise UserError(_("You can not delete this record only 'General Manager' can delete this record."))
        return super(Product, self).unlink()


class ProductTemplate(models.Model):
    _inherit = "product.template"

    def unlink(self):
        if not self.user_has_groups('mvf_customization.group_general_manager'):
            raise UserError(_("You can not delete this record only 'General Manager' can delete this record."))
        return super(ProductTemplate, self).unlink()


class ProductGroup(models.Model):
    _name = "mvf.product.group"
    _description = "Product Group"

    name = fields.Char(string="Name", required=True)
    code = fields.Char(size=1, required=True, index=True)
    company_id = fields.Many2one('res.company', 'Company', index=True, default=lambda self: self.env.company)


class ProductType(models.Model):
    _name = "mvf.product.type"
    _description = "Product Type"

    name = fields.Char(string="Name", required=True)
    code = fields.Char(size=1, required=True, index=True)
    company_id = fields.Many2one('res.company', 'Company', index=True, default=lambda self: self.env.company)


class ProductItem(models.Model):
    _name = "mvf.product.item"
    _description = "Product Item"

    name = fields.Char(string="Name", required=True)
    code = fields.Char(size=2, required=True, index=True)
    company_id = fields.Many2one('res.company', 'Company', index=True, default=lambda self: self.env.company)
    model_ids = fields.One2many(comodel_name='mvf.product.model', inverse_name='item_id', string="Models")


class ProductModel(models.Model):
    _name = "mvf.product.model"
    _description = "Product Model"

    name = fields.Char(string="Name", required=True)
    code = fields.Char(size=2, required=True, index=True)
    item_id = fields.Many2one(comodel_name='mvf.product.item', string="Item", readonly=True)
    company_id = fields.Many2one('res.company', 'Company', related="item_id.company_id", store=True)
