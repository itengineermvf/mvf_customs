# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from . import product
from . import product_document
from . import ir_attachment
from . import stock_production_lot
from . import stock_quant_package
