# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo.osv import expression
from odoo import api, fields, models


class ProductionLot(models.Model):
    _inherit = 'stock.production.lot'
    _order = 'name'

    @api.depends('quant_ids', 'quant_ids.quantity')
    def _compute_is_used(self):
        for lot in self:
            quants = lot.quant_ids.filtered(lambda q: q.location_id.usage in ['internal', 'transit'])
            lot.is_used = (sum(quants.mapped('quantity')) <= 0)

    is_used = fields.Boolean(string="Used?", compute='_compute_is_used', store=True)

    @api.model
    def name_search(self, name, args, operator='ilike', limit=100):
        picking_type_code = None

        # manufacturing
        active_mo_id = self._context.get('active_mo_id', False)
        if active_mo_id:
            active_mo_id = self.env['mrp.production'].browse(active_mo_id)
            picking_type_code = active_mo_id.picking_type_id.code

        # stock transfers
        picking_id = self._context.get('active_model') == 'stock.picking' and\
            self._context.get('active_id', False)
        if not picking_id and self._context.get('active_picking_id', False):
            picking_id = self._context['active_picking_id']
        if picking_id:
            picking_id = self.env['stock.picking'].browse(picking_id)
            picking_type_code = picking_id.picking_type_id.code

        if not picking_type_code:
            picking_type_code = self._context.get('picking_type_code', False)

        if picking_type_code is not None:
            lot_ids = self.search(args, limit=limit)
            # # Logic w/o is_used field
            # lot_ids_with_negative_quants = lot_ids.filtered(
            #             lambda lot: sum(lot.quant_ids.filtered(
            #                 lambda quant: quant.location_id.usage in ('internal', 'transit')).mapped('quantity')
            #             ) <= 0
            #         )
            lot_ids_with_negative_quants = lot_ids.filtered(lambda lot: lot.is_used)
            if picking_type_code in ('outgoing', 'internal', 'mrp_operation'):
                lot_ids -= lot_ids_with_negative_quants
            else:   # for incoming operation
                # no more needed because we filter negative quants from lots
                # keep as it is for future use/ref
                lot_ids |= lot_ids_with_negative_quants
            args = expression.AND([[('id', 'in', lot_ids.ids)], args])
        return super(ProductionLot, self).name_search(
            name=name,
            args=args,
            operator=operator,
            limit=limit
        )
